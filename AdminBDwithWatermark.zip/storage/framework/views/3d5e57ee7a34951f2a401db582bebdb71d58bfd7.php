

<?php $__env->startSection('content'); ?>
<div class="wrapper">
		
		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Subscription<a href="addsubcription"><button
											class="btn btn-primary btn-round float-right btn-primary"><i
												classs="la la-plus">Add Subcsription</i></button></a></h3>
							</div>
							<div class="card-body">
								<div class="table-responsive">
									<table class="table table-striped table-striped-bg-default mt-3">
										<thead>
											<tr>
												<th scope="col">Sr.No</th>
												<th scope="col">Package Name</th>
												<th scope="col">Pakage Validity</th>
												<th scope="col">Package Price</th>
												<!-- <th scope="col">Package Image</th> -->
												<th scope="col">Action</th>

											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1</td>
												<td>A Pack</td>
												<td>3 Months</td>
												<td>350</td>
												<!-- <td><img src="Images\a.jpg" class="img-fluid" alt="Responsive"
														style="width: 30px;height:30px "></td> -->
												<td><button type="button" style="height: 28px; width : 28px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-edit la-2x"
															style="margin : -7px -11px;"></i></button>
													<button type="button" style="height: 28px; width: 28px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-trash-o la-2x"
															style="margin: -7px -12px;"></i></button>
												</td>
											</tr>
											<tr>
												<td>2</td>
												<td>B Pack</td>
												<td>6 Months</td>
												<td>450</td>
												<!-- <td><img src="Images\b.jpg" class="img-fluid" alt="Responsive"
														style="height: 30px;width: 30px;"></td> -->
												<td><button type="button"
														class="btn btn-light btn-outline btn-sm border border-dark"
														style="height: 28px ;width: 28px"><i class="la la-edit la-2x"
															style="margin : -7px -11px;"></i></button>
													<button type="button"
														class="btn btn-light btn-outline btn-sm border border-dark"
														style="height: 28px ;width: 28px"><i class="la la-trash-o la-2x"
															style="margin: -7px -12px;"></i></button>
												</td>
											</tr>
											<tr>
												<td>3</td>
												<td>C Pack</td>
												<td>12 Months</td>
												<td>800</td>
												<!-- <td><img src="Images\c.png" class="img-fluid" alt="Responsive"
														style="width: 30px;height: 30px;"></td> -->
												<td><button type="button" style="height: 28px; width : 28px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-edit la-2x"
															style="margin : -7px -11px;"></i></button>
													<button type="button" style="height: 28px; width: 28px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-trash-o la-2x"
															style="margin: -7px -12px;"></i></button>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\gdrive\Laravel Project\AdminBD\resources\views/subscription.blade.php ENDPATH**/ ?>