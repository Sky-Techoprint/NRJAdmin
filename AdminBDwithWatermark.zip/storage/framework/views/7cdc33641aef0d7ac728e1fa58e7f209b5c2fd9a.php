<!DOCTYPE html>
<html>

<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>NRJ Digital Branding</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
		name='viewport' />
	<link rel="stylesheet"
		href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- <link rel="stylesheet" href="css/demo.css"> -->
        <link rel="stylesheet" href="css/ready.css">
        <link rel="stylesheet" href="css/ready.css.map">
	    <link rel="stylesheet" href="css/ready.min.css">
</head>

<body>


    <div class="header">
        <?php $__env->startSection('header'); ?>
            <div class="main-header">
                <div class="logo-header">
                    <a href="/" class="logo">
                        NRJ Digital Brandding
                    </a>
                    <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse"
                        data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <button class="topbar-toggler more"><i class="la la-ellipsis-v"></i></button>
                </div>
                <nav class="navbar navbar-header navbar-expand-lg">
                    <div class="container-fluid">

                        <form class="navbar-left navbar-form nav-search mr-md-3" action="">
                            <div class="input-group">
                                <input type="text" placeholder="Search ..." class="form-control">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-search search-icon"></i>
                                    </span>
                                </div>
                            </div>
                        </form>
                        <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
                            <li class="nav-item dropdown hidden-caret">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="la la-envelope"></i>
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown hidden-caret">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="la la-bell"></i>
                                    <span class="notification">3</span>
                                </a>
                                <ul class="dropdown-menu notif-box" aria-labelledby="navbarDropdown">
                                    <li>
                                        <div class="dropdown-title">You have 4 new notification</div>
                                    </li>
                                    <li>
                                        <div class="notif-center">
                                            <a href="#">
                                                <div class="notif-icon notif-primary"> <i class="la la-user-plus"></i>
                                                </div>
                                                <div class="notif-content">
                                                    <span class="block">
                                                        New user registered
                                                    </span>
                                                    <span class="time">5 minutes ago</span>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="notif-icon notif-success"> <i class="la la-comment"></i> </div>
                                                <div class="notif-content">
                                                    <span class="block">
                                                        Rahmad commented on Admin
                                                    </span>
                                                    <span class="time">12 minutes ago</span>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="notif-img">
                                                    <img src="img/profile2.jpg" alt="Img Profile">
                                                </div>
                                                <div class="notif-content">
                                                    <span class="block">
                                                        Reza send messages to you
                                                    </span>
                                                    <span class="time">12 minutes ago</span>
                                                </div>
                                            </a>
                                            <a href="#">
                                                <div class="notif-icon notif-danger"> <i class="la la-heart"></i> </div>
                                                <div class="notif-content">
                                                    <span class="block">
                                                        Farrah liked Admin
                                                    </span>
                                                    <span class="time">17 minutes ago</span>
                                                </div>
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="see-all" href="javascript:void(0);"> <strong>See all
                                                notifications</strong> <i class="la la-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="profile-pic" href="#" > <img src="img/profile.jpg" alt="user-img" width="36"
                                        class="img-circle"><span>Niraj</span></span> </a>
                               
                                <!-- /.dropdown-user -->
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        <?php echo $__env->yieldSection(); ?>
    </div>
    
    <div class="sidebar">
        <?php $__env->startSection('slidebar'); ?>
            <div class="sidebar">
                <div class="scrollbar-inner sidebar-wrapper">

                    <ul class="nav">
                        <li class="nav-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
                            <a href="/">
                                <i class="la la-dashboard"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>
                        <!-- <li class="nav-item">
                            <a href="maincategory">
                                <i class="la la-dashboard"></i>
                                <p>Main Categories</p>
                            </a>
                        </li> -->
                        <li class="nav-item <?php echo e(Request::is('subcategory') ? 'active' : ''); ?>" >
                            <a href="subcategory">
                                <i class="la la-table"></i>
                                <p>Add Category</p>
                            </a>
                        </li>
                 

                        <li class="nav-item <?php echo e(Request::is('premium_images') ? 'active' : ''); ?> <?php echo e(Request::is('greeting_images') ? 'active' : ''); ?> <?php echo e(Request::is('marketing_tools') ? 'active' : ''); ?>">
                            <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link"> <i class="la la-photo"></i>
                                <p>Upload Files</p></a>
                            <ul class="collapse  " id="homeSubmenu">
                                <li class="<?php echo e(Request::is('premium_images') ? 'active' : ''); ?>"><a  href="premium_images">Premium Images</a></li>
                                <li class="<?php echo e(Request::is('greeting_images') ? 'active' : ''); ?>"><a  href="greeting_images">Greeting Images</a></li>
                                <li class="<?php echo e(Request::is('marketing_tools') ? 'active' : ''); ?>"><a  href="marketing_tools">Marketing Tools</a></li>
                            </ul>
                        </li>


                

                        

                   



                        <!-- <li class="nav-item">
                            <a href="tools">
                                <i class="la la-wrench"></i>
                                <p>Tools</p>
                            </a>
                        </li> -->
                        <!-- <li class="nav-item">
                            <a href="fileupload">
                                <i class="la la-upload"></i>
                                <p>File Upload</p>
                            </a>
                        </li> -->
                        <li class="nav-item <?php echo e(Request::is('subscription') ? 'active' : ''); ?>">
                            <a href="subscription">
                                <i class="la la-bell"></i>
                                <p>Subscriptions</p>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(Request::is('pending') ? 'active' : ''); ?> <?php echo e(Request::is('ongoing') ? 'active' : ''); ?>   <?php echo e(Request::is('completedlist') ? 'active' : ''); ?> ">
                            <a href="pending">
                                <i class="la la-cart-plus"></i>
                                <p>Orders</p>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(Request::is('free') ? 'active' : ''); ?> <?php echo e(Request::is('paid') ? 'active' : ''); ?> ">
                            <a href="free">
                                <i class="la la-user"></i>
                                <p>Users</p>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(Request::is('viewdetails') ? 'active' : ''); ?>">
                            <a href="viewdetails">
                                <i class="la la-eye"></i>
                                <p>Image/Files Details</p>
                            </a>
                        </li>
                        <!--<li class="nav-item">
                                <a href="icons">
                                    <i class="la la-exclamation circle"></i>
                                    <p>Inquiry List</p>
                                </a>
                            </li> -->
                    </ul>
                </div>
            </div>
        <?php echo $__env->yieldSection(); ?>
    </div>

    <div class="content">
        <?php $__env->startSection('content'); ?>
        
        <?php echo $__env->yieldSection(); ?>
    </div>

    <div class="footer">
        <?php $__env->startSection('footer'); ?>
            <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul class="nav">
                            <li class="nav-item">
                                <a class="nav-link" href="">
                                    skyolane
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                    Help
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                   
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <div class="copyright ml-auto">
                        2020, made with <i class="la la-heart heart text-danger"></i> by <a
                            href="http://skyolane.info">Skyolane</a>
                    </div>
                </div>
            </footer>
        <?php echo $__env->yieldSection(); ?>
    </div> 
    <script>
    
     </script>

    <script src="js/core/jquery.3.2.1.min.js"></script>
    <script src="js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
    <script src="js/core/popper.min.js"></script>
    <script src="js/core/bootstrap.min.js"></script>
    <script src="js/plugin/chartist/chartist.min.js"></script>
    <script src="js/plugin/chartist/plugin/chartist-plugin-tooltip.min.js"></script>
    <script src="js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
    <script src="js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
    <script src="js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
    <script src="js/plugin/jquery-mapael/maps/world_countries.min.js"></script>
    <script src="js/plugin/chart-circle/circles.min.js"></script>
    <script src="js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
    <script src="js/ready.min.js"></script>

    <!-- <script src="js/demo.js"></script> -->
    
</body>
</html><?php /**PATH E:\gdrive\Laravel Project\AdminBD\resources\views/master.blade.php ENDPATH**/ ?>