

<?php $__env->startSection('content'); ?><div class="wrapper">
		
		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">File Upload</h3>
							</div>
							<div class="card-body">

								<div class="form-group">
									<label for="selecttools">Select Tools</label>
									<select class="form-control w-50" id="maincategory" style="width: 500px">
										<option>A</option>
										<option>B</option>
										<option>C</option>
										<option>D</option>
										<option>E</option>
									</select>
								</div>
								<div class="form-group">
									<label for="selectfile">Select File</label>
									<input type="file" class="form-control-file" id="selectfile">
									<p>Select File</p>
								</div>
								<div style="width: 500px" class="ml-2">
									<a href="#"><button class="btn btn-primary btn-round"><i
												classs="la la-plus">Upload</i></button></a>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\AdminBD\resources\views/fileupload.blade.php ENDPATH**/ ?>