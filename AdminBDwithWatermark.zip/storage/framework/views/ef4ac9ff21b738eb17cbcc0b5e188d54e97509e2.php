 <?php $__env->startSection('content'); ?>

<div class="wrapper">

    <div class="main-panel">
        <div class="content">
            <div class="container-fluid">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Add Premium Image</h3>
                        </div>
                        <div class="card-body">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-7">
                                        <!-- <div class="form-group ">
                                            <label for="maincategory">Main Category</label>
                                            <select class="form-control w-50" id="maincategory">
											<option>A</option>
											<option>B</option>
											<option>C</option>
											<option>D</option>
											<option>E</option>
										</select>
                                        </div> -->
                                        <div class="form-group">
                                            <label for="subcategory">Sub Category</label>
                                            <select class="form-control w-50" id="subcategory">
											<option>a</option>
											<option>b</option>
											<option>c</option>
											<option>d</option>
											<option>e</option>
										</select>
                                        </div>

                                        <div class="form-check">
                                            <label>Price</label><br />
                                            <label class="form-radio-label">
									<input class="form-radio-input" type="radio" name="optionsRadios" value=""
										checked="">
									<span class="form-radio-sign">Free</span>
								</label>
                                            <label class="form-radio-label">
									<input class="form-radio-input" type="radio" name="optionsRadios" value="">
									<span class="form-radio-sign">Paid</span>
								</label>
                                            <!-- <input type="text" style="padding-bottom:5px" id="paid" class=""> -->
                                        </div>


                                        <div class="form-group" style="margin-top: -10px">
                                            <label for="uploadimage">Upload Image</label>
                                            <input type="file" class="form-control-file" id="uploadimage" accept="image/*" onchange="loadFile(event)">
                                            <p>*Upload Image File Only</p>
                                        </div>

                                        <script>
                                            var loadFile = function(event) {
                                                var output = document.getElementById('output');
                                                output.src = URL.createObjectURL(event.target.files[0]);
                                                output.onload = function() {
                                                    URL.revokeObjectURL(output.src) // free memory
                                                }
                                            };
                                        </script>


                                        <div class="form-group  ">

                                            <p style="margin-top: -10px; margin-bottom: 15px ;  color: black;">Watermark Setting</p>
                                            <span class="mr-2" style="font-weight: 600;">Set X :</span><input type="text" id="paid" class="pb-0 " style=" width: 45px;
								background-color: #fff; border: solid 1px rgb(46, 43, 43);"><span class="ml-2 mr-2" style="font-weight: 600;">Set Y :</span><input type="text" id="paid" class="pb-0" style=" width: 45px;
								background-color: #fff; border: solid 1px rgb(46, 43, 43);">


                                        </div>

                                        <div class="form-group " style="margin-top: -10px">
                                            <span class="mr-2" style="font-weight: 600;">Font Size :
                                <select id="countryCode" name="countryCode" style="max-width: 80px; border-color: black; height: 32px;;" class="custom-select  bg-white  border-md font-weight-bold text-muted">
									<option value="">+18</option>
									<option value="">+20</option>
									<option value="">+22</option>
									<option value="">+26</option>
									<option value="">+30</option>
								</select>
							</div>
							
							<div class="form-group  "  style="margin-top: -10px">
                            	<span class="mr-2" style="font-weight: 600;">Rotation :</span><input type="text" id="paid" class="pb-0 " style=" width: 45px;
								background-color: #fff; border: solid 1px rgb(46, 43, 43);">
                                            </p>
                                        </div>
                                        <!-- <div class="form-check">
                                <p>Color Picker</p>
                                <input style="width: 50px; height:25px; " type="color" id="mycolor">
                                <button class="btn btn-outline btn-sm" style="margin-bottom: 5px; width: auto; margin-left: 10px" onclick="myfunction()"><span>Select</span></button>
                                <p id="demo"></p>
                                <script>
                                    function myfunction() {
                                        var x = document.getElementById("mycolor").value;
                                        document.getElementById("demo").innerHTML = x;
                                    }
                                </script>
                            </div> -->

                                        <div style="width: 50px" class="ml-2">
                                            <a href="#"><button class="btn btn-primary btn-round"><i
												classs="la la-plus">Upload</i></button></a>
                                        </div>
                                    </div>
                                    <div class="col-md-5 ml-0 mr-0 pl-0 pr-0">
                                        <p style="font-weight: 800; font-size: 20px;">priview :</p>
                                        <img id="output" style="height: 350px;  border: solid 10px #383737; border-radius: 20px; width:400px">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\gdrive\Laravel Project\AdminBD\resources\views/premium_images.blade.php ENDPATH**/ ?>