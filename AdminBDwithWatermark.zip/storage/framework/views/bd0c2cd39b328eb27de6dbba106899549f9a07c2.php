<!doctype html>
<html lang="en">
<head>
    <title>Laravel Add Watermark on Images</title>
</head>
<body style="margin-top: 40px; text-align: center;">

<h1>Laravel Add Watermark</h1>

<img src="<?php echo e($new_image); ?>" alt="Watermark">

</body>
</html><?php /**PATH C:\xampp\htdocs\AdminBD\resources\views/show_watermark.blade.php ENDPATH**/ ?>