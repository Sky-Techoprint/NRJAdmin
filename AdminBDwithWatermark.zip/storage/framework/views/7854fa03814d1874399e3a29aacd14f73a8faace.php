

<?php $__env->startSection('content'); ?>

<div class="wrapper">

		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Upload Image</h3>
							</div>
							<div class="card-body">
								<div class="form-group">
									<label for="maincategory">Main Category</label>
									<select class="form-control w-50" id="maincategory">
										<option>A</option>
										<option>B</option>
										<option>C</option>
										<option>D</option>
										<option>E</option>
									</select>
								</div>
								<div class="form-group">
									<label for="subcategory">Sub Category</label>
									<select class="form-control w-50" id="subcategory">
										<option>a</option>
										<option>b</option>
										<option>c</option>
										<option>d</option>
										<option>e</option>
									</select>
								</div>

								<div class="form-group">
									<label for="watermarkposition">WaterMark Position</label><br>
									<!-- Default inline 1-->
									<div class="custom-control custom-checkbox custom-control-inline">
										<input type="checkbox" class="custom-control-input" id="defaultInline1">
										<label class="custom-control-label" for="defaultInline1">Top-Right</label>
									</div>
									<!-- Default inline 2-->
									<div class="custom-control custom-checkbox custom-control-inline">
										<input type="checkbox" class="custom-control-input" id="defaultInline2">
										<label class="custom-control-label" for="defaultInline2">Top-Left</label>
									</div>
									<!-- Default inline 3-->
									<div class="custom-control custom-checkbox custom-control-inline">
										<input type="checkbox" class="custom-control-input" id="defaultInline3">
										<label class="custom-control-label" for="defaultInline3">Bottom-Right</label>
									</div>
									<div class="custom-control custom-checkbox custom-control-inline">
										<input type="checkbox" class="custom-control-input" id="defaultInline4">
										<label class="custom-control-label" for="defaultInline4">Bottom-Left</label>
									</div>
									<div class="custom-control custom-checkbox custom-control-inline">
										<input type="checkbox" class="custom-control-input" id="defaultInline5">
										<label class="custom-control-label" for="defaultInline5">Center</label>
									</div>
									<div class="custom-control custom-checkbox custom-control-inline">
										<input type="checkbox" class="custom-control-input" id="defaultInline6">
										<label class="custom-control-label" for="defaultInline6">Custom</label>
									</div>
								</div>


								<div class="form-group">
									<p>Color Picker</p>
									<input style="width: 50px; height:25px; " type="color" id="mycolor">
									<button class="btn btn-outline btn-sm"
										style="margin-bottom: 5px; width: auto; margin-left: 10px"
										onclick="myfunction()"><span>Select</span></button>
									<p id="demo"></p>
									<script>
										function myfunction() {
											var x = document.getElementById("mycolor").value;
											document.getElementById("demo").innerHTML = x;
										}
									</script>
								</div>

								<div class="form-group" style="margin-top: -20px">
									<label for="uploadimage">Upload Image</label>
									<input type="file" class="form-control-file" id="uploadimage" accept="image/*">
									<p>*Upload Image File Only</p>
								</div>
								<div style="width: 5000px" class="ml-2">
									<a href="#"><button class="btn btn-primary btn-round"><i
												classs="la la-plus">Upload</i></button></a>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>

	</div>
<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\AdminBD\resources\views/imgupload.blade.php ENDPATH**/ ?>