
	
<?php $__env->startSection('content'); ?>
<div class="wrapper">
		
		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Add Tools</h3>
							</div>
							<div class="card-body">
								<div class="form-group">
									<label for="maincategory">Main Category</label>
									<select class="form-control w-50" id="maincategory">
										<option>A</option>
										<option>B</option>
										<option>C</option>
										<option>D</option>
										<option>E</option>
									</select>
								</div>
								<div class="form-group">
									<label for="subcategory">Sub Category</label>
									<select class="form-control w-50" id="subcategory">
										<option>a</option>
										<option>b</option>
										<option>c</option>
										<option>d</option>
										<option>e</option>
									</select>
								</div>
								<div class="form-group">
									<label for="uploadimage">Upload Image</label>
									<input type="file" class="form-control-file" id="uploadimage" accept="image/*">
									<p>*Upload Image File Only</p>
								</div>
								<div style="width: 5000px" class="ml-2">
									<a href="#"><button class="btn btn-primary btn-round"><i classs="la la-plus">Add
												Tools</i></button></a>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>

	</div>
<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\gdrive\Laravel Project\AdminBD\resources\views/addtools.blade.php ENDPATH**/ ?>