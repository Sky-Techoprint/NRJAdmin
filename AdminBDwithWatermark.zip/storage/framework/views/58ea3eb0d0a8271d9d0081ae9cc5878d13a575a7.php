

<?php $__env->startSection('content'); ?>
<div class="wrapper">
		
		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Tools<a href="addtools"><button
											class="btn btn-primary btn-round float-right btn-primary"><i
												classs="la la-plus">Add Tools</i></button></a></h3>
							</div>
							<div class="card-body">
								<div class="table-responsive">
									<table class="table table-striped table-striped-bg-default mt-3 col-md-6">
										<thead>
											<tr>
												<th scope="col">Sr.No</th>
												<th scope="col">Main Category</th>
												<th scope="col">Sub Category</th>
												<th scope="col">Image</th>
												<th scope="col">Price</th>
												<th scope="col">Action</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1</td>
												<td>A</td>
												<td>a</td>
												<td><img src="Images\a.jpg" class="img-fluid" alt="Responsive"
														style="width:30px;height:30px;"></td>
												<td>10</td>
												<td><button type="button" style="height: 28px; width : 28px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-edit la-2x"
															style="margin : -7px -11px;"></i></button>
													<button type="button" style="height: 28px; width: 28px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-trash-o la-2x"
															style="margin: -7px -12px;"></i></button>
												</td>
											</tr>
											<tr>
												<td>2</td>
												<td>B</td>
												<td>b</td>
												<td><img src="Images\b.jpg" class="img-fluid" alt="Responsive"
														style="width: 30px;height: 30px;"></td>
												<td>20</td>
												<td><button type="button"
														class="btn btn-light btn-outline btn-sm border border-dark"
														style="height: 28px ;width: 28px"><i class="la la-edit la-2x"
															style="margin : -7px -11px;"></i></button>
													<button type="button"
														class="btn btn-light btn-outline btn-sm border border-dark"
														style="height: 28px ;width: 28px"><i class="la la-trash-o la-2x"
															style="margin: -7px -12px;"></i></button>
												</td>
											</tr>
											<tr>
												<td>3</td>
												<td>C</td>
												<td>c</td>
												<td><img src="Images\c.png" class="img-fluid" alt="Responsive"
														style="width: 30px;height: 30px;"></td>
												<td>30</td>
												<td><button type="button" style="height: 28px; width : 28px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-edit la-2x"
															style="margin : -7px -11px;"></i></button>
													<button type="button" style="height: 28px; width: 28px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-trash-o la-2x"
															style="margin: -7px -12px;"></i></button>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>



				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\gdrive\Laravel Project\AdminBD\resources\views/tools.blade.php ENDPATH**/ ?>