

<?php $__env->startSection('content'); ?>
	<div class="wrapper">
		
		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
							<h3 class="card-title">User<a href="addpaiduser"><button
											class="btn btn-primary btn-round float-right btn-primary"><i
												classs="la la-plus">Add Paid User</i></button></a></h3>
							</div>
							<div class="card-body">
								<ul class="nav nav-pills nav-primary center-pills">
									<li class="nav-item">
										<a class="nav-link" href="free">Free</a>
									</li>
									<li class="nav-item">
										<a class="nav-link active" href="paid">Paid</a>
									</li>
								</ul>
							</div>
							<div class="card-body">
								<div class="table-responsive">
									<table class="table table-striped table-striped-bg-default mt-3">
										<thead>
											<tr>
												<th scope="col">Sr.No</th>
												<th scope="col">User</th>
												<th scope="col">User Name</th>
												<th scope="col">User ID</th>
												<th scope="col">User Mobile</th>
												<th scope="col">User E-Mail</th>
												<th scope="col">Current Subsription</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1</td>
												<td>A</td>
												<td>Steve</td>
												<td>steve.a</td>
												<td>12345</td>
												<td>steve.gmail.com</td>
												<td>Plan A</td>
											</tr>
											<tr>
												<td>2</td>
												<td>B</td>
												<td>Ben</td>
												<td>ben.b</td>
												<td>54321</td>
												<td>ben.gmail.com</td>
												<td>Plan B</td>
											</tr>
											<tr>
												<td>3</td>
												<td>C</td>
												<td>Charles</td>
												<td>charle.c</td>
												<td>852369</td>
												<td>charle.gmail.com</td>
												<td>Plan C</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>








			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AdminBD\resources\views/paid.blade.php ENDPATH**/ ?>