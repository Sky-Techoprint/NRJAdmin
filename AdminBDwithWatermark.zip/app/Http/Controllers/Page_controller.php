<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Image;
class Page_controller extends Controller
{
    //

    function addcategory()
    {
        return view('addcategory');
    }

    function addmain()
    {
        return view('addmain');
    }

    function addsubcription()
    {
        return view('addsubcription');
    }

    function addtools()
    {
        return view('marketing_tools');
    }

    function completedlist()
    {
        return view('completedlist');
    }

    function fileupload()
    {
        return view('fileupload');
    }

    function free()
    {
        return view('free');
    }

    function PremiumImages()
    {
        //$path=$_POST['imagepath'];
        if(!isset($_POST['imagepath']))
        {
            $new_image="";
            return view('premium_images',compact('new_image'));
        }
        
        if(isset($_POST['imagepath']))
        {
            $path=$_POST['imagepath'];
        }
        
        $a=explode("\\",$path);
        $imgname=end($a);
        $imgname="img/".$imgname;
        $img = Image::make(public_path($imgname));
       
        $x=$_POST['x'];
        $y=$_POST['y'];
        if($x=="") $x=100;
        if($y=="") $y=100;
        $textv="MyNotePaper";
        $img->text($textv, $x, $y, function ($font) {
        $font_size=$_POST['fontsize'];
        if($font_size=="") $font_size=12;
        $angle=$_POST['angle'];
        if($angle=="") $angle=0;
        $color="#f4d442";
        if(isset($_POST['selcolor']))
        {
            $color=$_POST['selcolor'];
        }
        
       

            $font->file(public_path('fonts/1.ttf'));
            $font->size=$font_size;
            $font->color($color);
            $font->align('center');
            $font->valign('top');
            $font->angle=$angle;
        });

        $img->save(public_path('img/new-image.jpg'));

        $img->encode('jpg');
        $type = 'jpg';
        $new_image = 'data:image/' . $type . ';base64,' . base64_encode($img);

        return view('premium_images',compact('new_image'));
    }

    function index()
    {
        return view('index');
    }

    function inquiry()
    {
        return view('inquiry');
    }

    function maincategory()
    {
        return view('maincategory');
    }

    function master()
    {
        return view('master');
    }

    function ongoing()
    {
        return view('ongoing');
    }

    function paid()
    {
        return view('paid');
    }

    function pending()
    {
        return view('pending');
    }

    function subcategory()
    {
        return view('subcategory');
    }

    function subscription()
    {
        return view('subscription');
    }

    function tools()
    {
        return view('tools');
    }

    function viewdetails()
    {
        return view('viewdetails');
    }

    function addpaiduser()
    {
        return view('addpaiduser');
    }

    function GreetingImages()
    {
        return view('greeting_images');
    }


    
}
