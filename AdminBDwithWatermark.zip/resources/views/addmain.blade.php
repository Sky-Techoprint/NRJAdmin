@extends('master')

@section('content')

	<div class="wrapper">

		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Add Main Category</h3>
							</div>
							<div class="card-body">
								<div class="form-group">
									<label for="subcategory">Add Main Category</label>
									<input type="text" class="form-control w-50" id="subcategory" placeholder="Enter Here">
								</div>
								<div style="width: 500px">
									<a href="#"><button class="btn btn-primary btn-round"><i classs="la la-plus">Add
												Category</i></button></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>

@endsection
	