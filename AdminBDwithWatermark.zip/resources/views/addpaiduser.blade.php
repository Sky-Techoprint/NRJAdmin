@extends('master')

@section('content')<div class="wrapper">
	<div class="main-panel">
		<div class="content">
			<div class="container-fluid">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Add User</h3>
						</div>
						<div class="card-body">


                            <div class="form-group">
								<label for="subcategory">Name</label>
								<input type="text" class="form-control w-50" id="name" placeholder="Enter Your Name">
                            </div>
                            
                            <div class="form-group">
								<label for="subcategory">Designation</label>
								<input type="text" class="form-control w-50" id="Designation" placeholder="Enter Designation">
                            </div>

                            <div class="form-group">
								<label for="subcategory">Number</label>
								<input type="text" class="form-control w-50" id="Number" placeholder="Enter Your Number">
                            </div>
                            
							<div class="form-group">
								<label for="maincategory">Select plan</label>
								<select class="form-control w-50" id="maincategory">
									<option>3 Month</option>
									<option>6 Month</option>
									<option>1 Year</option>
								</select>
                            </div>
                            
                            <div class="form-group">
								<sapn><label for="subcategory">Start Date</label>
								<input type="text" class="form-control w-50" id="startdate" placeholder="Enter Start Date">
                            </div>
                             
                            <div class="form-group">
								<label for="subcategory">End Date</label>
								<input type="text" class="form-control w-50" id="enddate" placeholder="Enter End Date">
                            </div>
                            
                            
							
							<div style="width: 500px" class="ml-2">
								<a href="#"><button class="btn btn-primary btn-round"><i classs="la la-plus">Add
											user</i></button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
