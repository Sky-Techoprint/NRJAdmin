@extends('master')

@section('content')

	<div class="wrapper">
		
		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Inquiry</h3>
							</div>
							<div class="card-body">

								<div class="form-group">
									<label for="username">Username</label>
									<input type="text" class="form-control" id="username" placeholder="Enter here">
								</div>
								<div class="form-group">
									<label for="useremail">User E-mail</label>
									<input type="text" class="form-control" id="useremail" placeholder="Enter here">
								</div>
								<div class="form-group">
									<label for="usermobile">User Mobile Number</label>
									<input type="text" class="form-control" id="usermobile" placeholder="Enter here">
								</div>
								<div class="form-group">
									<label for="comments">Comments</label>
									<input type="textarea" class="form-control" id="comments" placeholder="Enter here">
								</div>
								<div class="form-group">
									<button class="btn btn-primary btn-round btn-primary"><i
											classs="la la-plus">Submit</i></button>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
@endsection

	