<?php

use App\Http\Controllers\Page_controller;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('addcategory', 'App\Http\Controllers\Page_controller@addcategory');
Route::get('addmain', 'App\Http\Controllers\Page_controller@addmain');
Route::get('addsubcription', 'App\Http\Controllers\Page_controller@addsubcription');
Route::get('marketing_tools', 'App\Http\Controllers\Page_controller@addtools');
Route::get('completedlist', 'App\Http\Controllers\Page_controller@completedlist');
Route::get('fileupload', 'App\Http\Controllers\Page_controller@fileupload');
Route::get('free', 'App\Http\Controllers\Page_controller@free');
Route::any('premium_images', 'App\Http\Controllers\Page_controller@PremiumImages');
Route::get('inquiry', 'App\Http\Controllers\Page_controller@inquiry');
Route::get('maincategory', 'App\Http\Controllers\Page_controller@maincategory');
Route::get('master', 'App\Http\Controllers\Page_controller@master');
Route::get('ongoing', 'App\Http\Controllers\Page_controller@ongoing');
Route::get('paid', 'App\Http\Controllers\Page_controller@paid');
Route::get('pending', 'App\Http\Controllers\Page_controller@pending');
Route::get('subcategory', 'App\Http\Controllers\Page_controller@subcategory');
Route::get('subscription', 'App\Http\Controllers\Page_controller@subscription');
Route::get('tools', 'App\Http\Controllers\Page_controller@tools');
Route::get('viewdetails', 'App\Http\Controllers\Page_controller@viewdetails');
Route::get('addpaiduser', 'App\Http\Controllers\Page_controller@addpaiduser');
Route::get('greeting_images', 'App\Http\Controllers\Page_controller@GreetingImages');
Route::get('watermark-image', 'App\Http\Controllers\WaterMarkController@imageWatermark');
Route::get('watermark-text', 'App\Http\Controllers\WaterMarkController@textWatermark');
Route::post('WaterMarkController/textWatermark', 'App\Http\Controllers\WaterMarkController@textWatermark');
