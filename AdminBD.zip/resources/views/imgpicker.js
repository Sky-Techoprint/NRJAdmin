const pickr6 = new Pickr({
  el: '#color-picker-6',
  useAsButton: true,

  components: {
    preview: true,
    opacity: true,
    hue: true,

    interaction: {
      hex: true,
      rgba: true,
      hsla: true,
      hsva: true,
      cmyk: true,
      input: true,
      clear: true,
      save: true
    }
  },

  onChange(hsva) {
    let colorObject = {
      hex: hsva.toHEX().toString(),
      rgba: hsva.toRGBA().toString(),
      hsla: hsva.toHSLA().toString(),
      hsva: hsva.toHSVA().toString(),
      cmyk: hsva.toCMYK().toString()
    };
    for (let col in colorObject) {
      $('#' + col).text(col + ': ' + colorObject[col]);
    }
  }
});