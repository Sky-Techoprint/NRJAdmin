@extends('master')

@section('content')
<div class="wrapper">
		
		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Orders</h3>
							</div>
							<div class="card-body">
								<ul class="nav nav-pills nav-primary center-pills">
									<li class="nav-item">
										<a class="nav-link active" href="pending">Pending</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="ongoing">Ongoing</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="completedlist">Completed</a>
									</li>

								</ul>
							</div>
							<div class="card-body">
								<div class="table-responsive">
									<table class="table table-striped table-striped-bg-default mt-3">
										<thead>
											<tr>
												<th scope="col">Sr.No</th>
												<th scope="col">Client Name</th>
												<th scope="col">Client Time</th>
												<th scope="col">Order Amount</th>
												<th scope="col">Client E-mail</th>
												<th scope="col">Client Number</th>
												<th scope="col">Action</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1</td>
												<td>John</td>
												<td>13 Sep 2020 15:36</td>
												<td>500</td>
												<td>john@gmail.com</td>
												<td>+91 9876543210</td>
												<td><button type="button" style="height: 32px; width : 32px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-check la-2x"
															style="margin : -5px -10px;"></i></button>
													<button type="button" style="height: 32px; width: 32px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-close la-2x"
															style="margin: -5px -10px;"></i></button>
												</td>
											</tr>
											<tr>
												<td>2</td>
												<td>Tom</td>
												<td>13 Sep 2020 16:46</td>
												<td>750</td>
												<td>tom@gmail.com</td>
												<td>+91 9801234567</td>
												<td><button type="button"
														class="btn btn-light btn-outline btn-sm border border-dark"
														style="height: 32px ;width: 32px"><i class="la la-check la-2x"
															style="margin : -5px -10px;"></i></button>
													<button type="button"
														class="btn btn-light btn-outline btn-sm border border-dark"
														style="height: 32px ;width: 32px"><i class="la la-close la-2x"
															style="margin: -4.5px -12px;"></i></button>
												</td>
											</tr>
											<tr>
												<td>3</td>
												<td>Mike</td>
												<td>10 Sep 2020 15:02</td>
												<td>600</td>
												<td>mike@gmail.com</td>
												<td>+91 9867543210</td>
												<td><button type="button" style="height: 32px; width : 32px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-check la-2x"
															style="margin : -5px -10px;"></i></button>
													<button type="button" style="height: 32px; width: 32px;"
														class="btn btn-light btn-outline-light btn-sm"><i
															class="la la-close la-2x"
															style="margin: -5px -10px;"></i></button>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
@endsection
	