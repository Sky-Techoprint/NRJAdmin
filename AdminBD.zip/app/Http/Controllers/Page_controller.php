<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Page_controller extends Controller
{
    //

    function addcategory()
    {
        return view('addcategory');
    }

    function addmain()
    {
        return view('addmain');
    }

    function addsubcription()
    {
        return view('addsubcription');
    }

    function addtools()
    {
        return view('marketing_tools');
    }

    function completedlist()
    {
        return view('completedlist');
    }

    function fileupload()
    {
        return view('fileupload');
    }

    function free()
    {
        return view('free');
    }

    function PremiumImages()
    {
        return view('premium_images');
    }

    function index()
    {
        return view('index');
    }

    function inquiry()
    {
        return view('inquiry');
    }

    function maincategory()
    {
        return view('maincategory');
    }

    function master()
    {
        return view('master');
    }

    function ongoing()
    {
        return view('ongoing');
    }

    function paid()
    {
        return view('paid');
    }

    function pending()
    {
        return view('pending');
    }

    function subcategory()
    {
        return view('subcategory');
    }

    function subscription()
    {
        return view('subscription');
    }

    function tools()
    {
        return view('tools');
    }

    function viewdetails()
    {
        return view('viewdetails');
    }

    function addpaiduser()
    {
        return view('addpaiduser');
    }

    function GreetingImages()
    {
        return view('greeting_images');
    }


    
}
