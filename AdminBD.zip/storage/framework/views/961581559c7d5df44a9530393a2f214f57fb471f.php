

<?php $__env->startSection('content'); ?>
<div class="wrapper">
	
		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Orders</h3>
							</div>
							<div class="card-body">
								<ul class="nav nav-pills nav-primary center-pills">
									<li class="nav-item">
										<a class="nav-link" href="pending">Pending</a>
									</li>
									<li class="nav-item">
										<a class="nav-link active" href="ongoing">Ongoing</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="completedlist">Completed</a>
									</li>

								</ul>
							</div>
							<div class="card-body">
								<div class="table-responsive">
									<table class="table table-striped table-striped-bg-default mt-3">
										<thead>
											<tr>
												<th scope="col">Sr.No</th>
												<th scope="col">Client Name</th>
												<th scope="col">Client Time</th>
												<th scope="col">Order Amount</th>
												<th scope="col">Client E-mail</th>
												<th scope="col">Client Number</th>
												<th scope="col">Action</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1</td>
												<td>Sharma</td>
												<td>13 Sep 2020 15:36</td>
												<td>590</td>
												<td>ram@gmail.com</td>
												<td>+91 9876543210</td>
												<td><button type="button"
														class="btn btn-light btn-outline-light">Accept</button></td>
											</tr>
											<tr>
												<td>2</td>
												<td>Verma</td>
												<td>13 Sep 2020 16:46</td>
												<td>750</td>
												<td>shyam@gmail.com</td>
												<td>+91 9801234567</td>
												<td><button type="button"
														class="btn btn-light btn-outline-dark">Accept</button></td>
											</tr>
											<tr>
												<td>3</td>
												<td>Ram</td>
												<td>10 Sep 2020 15:02</td>
												<td>600</td>
												<td>raj@gmail.com</td>
												<td>+91 9867543210</td>
												<td><button type="button"
														class="btn btn-light btn-outline-light ">Accept</button></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>

					</div>

				</div>
			</div>
		</div>

	</div>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\gdrive\Laravel Project\AdminBD\resources\views/ongoing.blade.php ENDPATH**/ ?>