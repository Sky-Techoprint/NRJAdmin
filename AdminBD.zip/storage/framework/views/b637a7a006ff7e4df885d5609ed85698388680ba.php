

<?php $__env->startSection('content'); ?>
<div class="wrapper">

	<div class="main-panel">
		<div class="content">
			<div class="container-fluid">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Image/Files Details</h3>
						</div>
						<div class="card-body">
							<div class="table-responsive solid-black">
								<table class="table mt-4 table-outline-bordered-bd"
									style="border: 1px solid rgb(0,0,0,0.1);">
									<thead>
										<tr class="bg-primary">
											<th scope="col" style="color: white; border: 1px solid rgb(0,0,0,0.9);">
												Sr.No</th>
											<th scope="col" style="color: white">Main Category</th>
											<th scope="col" style="color: white">Sub Category</th>
											<th scope="col" style="color: white">Image</th>
											<th scope="col" style="color: white">Action</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td style="border:2px solid black">1</td>
											<td>A Pack</td>
											<td>a</td>
											<td><img src="Images\a.jpg" class="img-fluid" alt="Responsive"
													style="width: 100px; height:100px"></td>
											<td><button type="button"
													class="btn btn-light btn-outline btn-sm border border-dark"
													style="height: 28px ;width: 28px"><i class="la la-edit la-2x"
														style="margin : -7px -11px;"></i></button>
												<button type="button"
													class="btn btn-light btn-outline btn-sm border border-dark"
													style="height: 28px ;width: 28px"><i class="la la-trash-o la-2x"
														style="margin: -7px -12px;"></i></button></td>
										</tr>
										<tr>
											<td style="border:2px solid black">2</td>
											<td>B Pack</td>
											<td>b</td>
											<td><img src="Images\b.jpg" class="img-fluid" alt="Responsive"
													style="width: 100px;height: 100px"></td>
											<td>
												<button type="button"
													class="btn btn-light btn-outline btn-sm border border-dark"
													style="height: 28px ;width: 28px"><i class="la la-edit la-2x"
														style="margin : -7px -11px;"></i></button>
												<button type="button"
													class="btn btn-light btn-outline btn-sm border border-dark"
													style="height: 28px ;width: 28px"><i class="la la-trash-o la-2x"
														style="margin: -7px -12px;"></i></button>
											</td>
										</tr>
										<tr>
											<td style="border:2px solid grey">3</td>
											<td>C Pack</td>
											<td>c</td>
											<td><img src="Images\c.png" class="img-fluid" alt="Responsive"
													style="width: 100px;height: 100px"></td>
											<td>
												<button type="button"
													class="btn btn-light btn-outline btn-sm border border-dark"
													style="height: 28px ;width: 28px"><i class="la la-edit la-2x"
														style="margin : -7px -11px;"></i></button>
												<button type="button"
													class="btn btn-light btn-outline btn-sm border border-dark"
													style="height: 28px ;width: 28px"><i class="la la-trash-o la-2x"
														style="margin: -7px -12px;"></i></button>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\AdminBD\resources\views/viewdetails.blade.php ENDPATH**/ ?>