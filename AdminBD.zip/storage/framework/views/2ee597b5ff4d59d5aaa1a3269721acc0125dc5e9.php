

<?php $__env->startSection('content'); ?>	
<div class="wrapper">
	
		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h3 class="card-title">Add Subscription</h3>
							</div>
							<div class="card-body">
								<div class="form-group">
									<label for="packagename">Package Name</label>
									<input type="text" class="form-control w-50" id="packagename"
										placeholder="Enter Here" style="width: 500px">
								</div>
								<div class="form-group">
									<label for="packagevalidity">Package Validity</label>
									<input type="text" style="width: 500px" class="form-control w-50"
										id="packagevalidity" placeholder="Enter Here">
								</div>
								<div class="form-group">
									<label for="packageprice">Package Price</label>
									<input type="text" style="width: 500px" class="form-control w-50" id="packageprice"
										placeholder="Enter Here">
								</div>
								<div class="form-group">
									<label for="packagename">Discounted Price</label>
									<input type="text" class="form-control w-50" id="packagename"
										placeholder="Enter Here" style="width: 500px">
								</div>
								<!-- <div class="form-group">
									<label for="packageimage">Package Image</label>
									<input type="file" class="form-control-file" id="packageimage" accept="image/*">
									<p>*Add Image File Only</p>
								</div> -->
								<div style="width: 500px" class="ml-2">
									<a href="#"><button class="btn btn-primary btn-round"><i classs="la la-plus">Add
												Subcription</i></button></a>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\gdrive\Laravel Project\AdminBD\resources\views/addsubcription.blade.php ENDPATH**/ ?>