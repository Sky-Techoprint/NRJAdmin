

<?php $__env->startSection('content'); ?><div class="wrapper">
	<div class="main-panel">
		<div class="content">
			<div class="container-fluid">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Add Category</h3>
						</div>
						<div class="card-body">
							<div class="form-group">
								<label for="maincategory">Main Category</label>
								<select class="form-control w-50" id="maincategory">
									<option>Premium Images</option>
									<option>Greeting Images</option>
									<option>Marketing Tools</option>
									
								</select>
							</div>
							<div class="form-group">
								<label for="subcategory">Sub Category</label>
								<input type="text" class="form-control w-50" id="subcategory" placeholder="Enter Here">
							</div>
							<div class="form-group">
								<label for="addimage">Add Icon</label>
								<input type="file" class="form-control-file" id="addimage" accept="image/*">
							</div>

							<div class="form-group">
								<label for="addimage">Choose Background Image</label>
								<input type="file" class="form-control-file" id="addimage" accept="image/*">
							</div>

							<!-- <p class="ml-2">*Add Image File Only</p> -->
							<div class="form-check">
								<label>Price</label><br />
								<label class="form-radio-label">
									<input class="form-radio-input" type="radio" name="optionsRadios" value=""
										checked="">
									<span class="form-radio-sign">Free</span>
								</label>
								<label class="form-radio-label">
									<input class="form-radio-input" type="radio" name="optionsRadios" value="">
									<span class="form-radio-sign">Paid</span>
									<input type="text" style="padding-bottom:5px" id="paid" class="w-50">
								</label>
							</div>
							
							<div style="width: 500px" class="ml-2">
								<a href="#"><button class="btn btn-primary btn-round"><i classs="la la-plus">Add
											Category</i></button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\gdrive\Laravel Project\AdminBD\resources\views/addcategory.blade.php ENDPATH**/ ?>