

<?php $__env->startSection('content'); ?>
<div class="wrapper">
	
	<div class="main-panel">
		<div class="content">
			<div class="container-fluid">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							 <h3 class="card-title">Main Categories <a href="addmain"><button
										class="btn btn-primary btn-round float-right btn-primary"><i
											classs="la la-plus">Add Category</i></button></a></h3>
						</div>
						<div class="card-body">
							<div class="table-responsive">
								<table class="table table-striped table-striped-bg-default mt-3">
									<thead>
										<tr>
											<th scope="col">Sr.No</th>
											<th scope="col">Main Category</th>
											<th scope="col">Sub Category</th>
											<th scope="col">Action</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>1</td>
											<td>A Pack</td>
											<td>a</td>
											<td><button type="button" style="height: 28px; width : 28px;"
													class="btn btn-light btn-outline-light btn-sm"><i
														class="la la-edit la-2x"
														style="margin : -7px -11px;"></i></button>
												<button type="button" style="height: 28px; width: 28px;"
													class="btn btn-light btn-outline-light btn-sm"><i
														class="la la-trash-o la-2x"
														style="margin: -7px -12px;"></i></button>
											</td>
										</tr>
										<tr>
											<td>2</td>
											<td>B Pack</td>
											<td>b</td>
											<td><button type="button"
													class="btn btn-light btn-outline btn-sm border border-dark"
													style="height: 28px ;width: 28px;"><i class="la la-edit la-2x"
														style="margin : -7px -11px;"></i></button>
												<button type="button"
													class="btn btn-light btn-outline btn-sm border border-dark"
													style="height: 28px ;width: 28px;"><i class="la la-trash-o la-2x"
														style="margin: -7px -12px;"></i></button>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>




</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\gdrive\Laravel Project\AdminBD\resources\views/maincategory.blade.php ENDPATH**/ ?>